def PTFind ( InputList, Thresholds ):
    
   TempList = []
   PTLocsList = []


    # Start loop to select a subset of 3 data pts
   for j in range(2,len(InputList)) :  
       
       # Start code for peak detection
       if (InputList[j-2] - InputList[j-1] < Thresholds[0]) and (InputList[j] - InputList[j-1] < Thresholds[1]):
           
           TempList.append(1) # Set peak/trough Flag to 1 for we've detected a peak
           TempList.append(j-1) # Store location of peak
           
           # Put info n TempList into  PTLocsList
           PTLocsList.append(TempList)
           TempList = []
           # End code for peak detection

       # Start code for trough detection
       elif (InputList[j-2] - InputList[j-1] > Thresholds[2]) and (InputList[j] - InputList[j-1] > Thresholds[3]):
           
           TempList.append(0) # Set peak/trough Flag to 0 for we've detected a trough
           TempList.append(j-1) # Store location of trough         
           # Put info n TempList into  PTLocsList
           PTLocsList.append(TempList)
           TempList = []
       # End code for trough detection
       return PTLocsList  